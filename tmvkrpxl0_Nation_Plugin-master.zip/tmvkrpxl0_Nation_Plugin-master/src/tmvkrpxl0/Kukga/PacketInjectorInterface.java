package tmvkrpxl0.Kukga;

import org.bukkit.entity.Player;

public interface PacketInjectorInterface {
	void addPlayer(Player p);
	void removePlayer(Player p);
}
